App.onJoinplayer.Add(function(player){

    let mbtis = ["ISFJ", "ISTJ", "INFP", "ISTP"];

    let nth = Math.floor(Math.random() * mbtis.length);

    player.moveSpeed = 250;
    player.title = mbtis[nth];
    player.sendUpdated();
})