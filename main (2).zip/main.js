App.onSay.Add(function(player, text){
    let message = player.name + '힝힝' + text +'힝구리퐁퐁';
    App.showCenterLabel(message); 
})
