App.onJoinPlayer.Add(function(player){
    App.showCenterLabel("welcome sua!")
})